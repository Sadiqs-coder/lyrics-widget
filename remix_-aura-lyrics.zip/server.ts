import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for AI Lyrics
  app.post("/api/lyrics/sync", async (req, res) => {
    const { song, artist } = req.body;
    if (!song) {
      return res.status(400).json({ error: "Song title is required" });
    }

    try {
      const prompt = `Generate word-by-word timed lyrics for "${song}" by "${artist || 'Unknown Artist'}". 
      Return ONLY a JSON array of objects with { "text": "word", "startTime": ms_offset, "endTime": ms_offset }.
      Ensure the timings are realistic for a typical duration of 3-4 minutes if you don't know the exact ones.
      Do not include any other text.`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        }
      });

      const lyrics = JSON.parse(response.text || "[]");
      res.json({ lyrics });
    } catch (error: any) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: "Failed to generate lyrics" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
