import React from 'react';
import { WidgetConfig, WidgetStyle } from '../types';
import { Settings, Play, Pause, RefreshCw, Type, Maximize, Palette, Activity } from 'lucide-react';
import { motion } from 'motion/react';

interface Props {
  config: WidgetConfig;
  setConfig: (config: WidgetConfig) => void;
  isPlaying: boolean;
  setIsPlaying: (p: boolean) => void;
  onRefresh: () => void;
  song: string;
  setSong: (s: string) => void;
  artist: string;
  setArtist: (a: string) => void;
}

export const Dashboard: React.FC<Props> = ({ 
  config, setConfig, isPlaying, setIsPlaying, onRefresh, song, setSong, artist, setArtist 
}) => {
  return (
    <div className="w-full max-w-4xl bg-black/40 backdrop-blur-2xl rounded-[2rem] border border-white/10 p-8 shadow-3xl text-white">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-orange-400 to-rose-400 bg-clip-text text-transparent italic">
          Aura Lyrics
        </h1>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-3 rounded-2xl bg-white/10 hover:bg-white/20 transition-all"
          >
            {isPlaying ? <Pause size={20} /> : <Play size={20} />}
          </button>
          <button 
            onClick={onRefresh}
            className="p-3 rounded-2xl bg-white/10 hover:bg-white/20 transition-all"
          >
            <RefreshCw size={20} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Left Side: Song Info */}
        <div className="space-y-6">
          <div>
            <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold mb-2 block">Active Media</label>
            <div className="space-y-3">
              <input 
                type="text" 
                value={song}
                onChange={(e) => setSong(e.target.value)}
                placeholder="Song Title"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-white/30 transition-all font-medium"
              />
              <input 
                type="text" 
                value={artist}
                onChange={(e) => setArtist(e.target.value)}
                placeholder="Artist Name"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-white/30 transition-all font-medium"
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold mb-4 block">Animation Style</label>
            <div className="grid grid-cols-3 gap-3">
              {(['zoom', 'typewriter', 'gradient'] as WidgetStyle[]).map(style => (
                <button
                  key={style}
                  onClick={() => setConfig({ ...config, style })}
                  className={`p-4 rounded-2xl border transition-all flex flex-col items-center gap-2 ${
                    config.style === style ? 'bg-white/20 border-white/40' : 'bg-white/5 border-white/5 hover:border-white/20'
                  }`}
                >
                  <Activity size={18} className={config.style === style ? 'text-orange-400' : 'text-white/40'} />
                  <span className="text-[10px] font-bold uppercase tracking-tight">{style}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Side: Customization */}
        <div className="space-y-8">
          <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Split-View Mode</span>
              <span className="text-[9px] text-white/20">Optimized for tablets</span>
            </div>
            <button 
              onClick={() => setConfig({ ...config, splitView: !config.splitView })}
              className={`w-12 h-6 rounded-full relative transition-all ${config.splitView ? 'bg-orange-500' : 'bg-white/10'}`}
            >
              <motion.div 
                animate={{ x: config.splitView ? 24 : 4 }}
                className="absolute top-1 left-0 w-4 h-4 bg-white rounded-full shadow-lg"
              />
            </button>
          </div>

          <div>
            <div className="flex justify-between items-center mb-4">
              <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Surface Opacity</label>
              <span className="text-[10px] font-mono text-white/60">{config.bgOpacity}%</span>
            </div>
            <input 
              type="range" 
              min="0" max="100" 
              value={config.bgOpacity}
              onChange={(e) => setConfig({ ...config, bgOpacity: parseInt(e.target.value) })}
              className="w-full accent-orange-400"
            />
          </div>

          <div>
            <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold mb-4 block">Typography</label>
            <select 
              value={config.fontFamily}
              onChange={(e) => setConfig({ ...config, fontFamily: e.target.value })}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none appearance-none cursor-pointer"
            >
              <option value="Inter, sans-serif">Inter (Modern Sans)</option>
              <option value="'JetBrains Mono', monospace">JetBrains Mono (Technical)</option>
              <option value="Georgia, serif">Georgia (Refined Serif)</option>
              <option value="'Space Grotesk', sans-serif">Space Grotesk (Tech Forward)</option>
            </select>
          </div>

          <div className="grid grid-cols-3 gap-4">
            {(['left', 'center', 'right'] as const).map(align => (
              <button
                key={align}
                onClick={() => setConfig({ ...config, textAlign: align })}
                className={`flex-1 py-1 px-4 text-[10px] font-bold uppercase tracking-widest rounded-full transition-all ${
                  config.textAlign === align ? 'bg-white text-black' : 'bg-white/5 text-white/40'
                }`}
              >
                {align}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
