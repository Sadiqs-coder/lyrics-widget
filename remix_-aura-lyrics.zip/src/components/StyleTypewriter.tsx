import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import { LyricWord } from '../types';

interface Props {
  words: LyricWord[];
  currentTime: number;
}

export const StyleTypewriter: React.FC<Props> = ({ words, currentTime }) => {
  const visibleWords = useMemo(() => {
    return words.filter(w => w.startTime <= currentTime);
  }, [words, currentTime]);

  return (
    <div className="flex flex-wrap justify-center gap-2 p-4 h-full content-center">
      {visibleWords.slice(-10).map((word, i) => (
        <motion.span
          key={`${word.text}-${word.startTime}`}
          initial={{ opacity: 0, width: 0 }}
          animate={{ opacity: 1, width: 'auto' }}
          className="text-white text-2xl font-medium overflow-hidden whitespace-nowrap"
        >
          {word.text}
        </motion.span>
      ))}
      <motion.span
        animate={{ opacity: [0, 1, 0] }}
        transition={{ repeat: Infinity, duration: 0.8 }}
        className="w-1 h-8 bg-white/50 self-end mb-1"
      />
    </div>
  );
};
