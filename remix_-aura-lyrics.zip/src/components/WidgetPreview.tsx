import React from 'react';
import { WidgetConfig, LyricWord } from '../types';
import { StyleZoom } from './StyleZoom';
import { StyleTypewriter } from './StyleTypewriter';
import { StyleGradient } from './StyleGradient';
import { motion } from 'motion/react';

interface Props {
  config: WidgetConfig;
  words: LyricWord[];
  currentTime: number;
  songInfo: { title: string; artist: string; albumArt?: string };
}

export const WidgetPreview: React.FC<Props> = ({ config, words, currentTime, songInfo }) => {
  const renderStyle = () => {
    switch (config.style) {
      case 'zoom':
        return <StyleZoom words={words} currentTime={currentTime} />;
      case 'typewriter':
        return <StyleTypewriter words={words} currentTime={currentTime} />;
      case 'gradient':
        return <StyleGradient words={words} currentTime={currentTime} />;
      default:
        return null;
    }
  };

  return (
    <div 
      className="relative w-full max-w-lg aspect-[2/1] rounded-3xl overflow-hidden shadow-2xl border border-white/10"
      style={{ 
        fontFamily: config.fontFamily,
        textAlign: config.textAlign
      }}
    >
      {/* Background with Blur/Glassmorphism */}
      <div 
        className="absolute inset-0 z-0 bg-black/40 backdrop-blur-xl"
        style={{ opacity: config.bgOpacity / 100 }}
      />
      
      {/* Album Art Background (Very blurred) */}
      {songInfo.albumArt && (
        <div 
          className="absolute inset-0 z-[-1] bg-cover bg-center scale-110 opacity-30 blur-2xl"
          style={{ backgroundImage: `url(${songInfo.albumArt})` }}
        />
      )}

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col">
        {/* Header - Media Info */}
        <div className="p-4 flex items-center gap-3">
          <div className="w-8 h-8 rounded-md bg-white/10 flex items-center justify-center overflow-hidden">
            {songInfo.albumArt ? (
              <img src={songInfo.albumArt} alt="Art" className="w-full h-full object-cover" />
            ) : (
              <div className="w-4 h-4 bg-white/20 rounded-full" />
            )}
          </div>
          <div className="flex flex-col">
            <span className="text-white/90 text-[10px] font-bold uppercase tracking-widest leading-none">
              Now Playing
            </span>
            <span className="text-white text-xs font-medium truncate max-w-[200px]">
              {songInfo.title} • {songInfo.artist}
            </span>
          </div>
        </div>

        {/* Lyrics Area */}
        <div className="flex-1 min-h-0 flex items-center justify-center p-4">
          {config.splitView ? (
            <div className="flex w-full h-full gap-4">
              {/* Full Stanza Left */}
              <div className="flex-1 bg-white/5 rounded-xl p-4 overflow-hidden border border-white/5">
                 <div className="mask-fade h-full"> {/* Fade mask for overflow */}
                    {words.map((w, idx) => {
                      const isActive = currentTime >= w.startTime && currentTime <= w.endTime;
                      return (
                        <span 
                          key={idx} 
                          className={`inline-block mr-1 mb-1 transition-colors duration-300 ${isActive ? 'text-white font-bold' : 'text-white/20'}`}
                          style={{ fontSize: '10px' }}
                        >
                          {w.text}
                        </span>
                      );
                    })}
                 </div>
              </div>
              {/* Current Word Right */}
              <div className="flex-1 flex items-center justify-center">
                {renderStyle()}
              </div>
            </div>
          ) : (
            renderStyle()
          )}
        </div>

        {/* Footer - Progress Bar (Simulated) */}
        <div className="p-2 pt-0">
          <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-white/40"
              style={{ width: `${(currentTime / (words[words.length - 1]?.endTime || 1)) * 100}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
