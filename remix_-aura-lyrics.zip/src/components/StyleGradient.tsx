import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import { LyricWord } from '../types';

interface Props {
  words: LyricWord[];
  currentTime: number;
}

export const StyleGradient: React.FC<Props> = ({ words, currentTime }) => {
  const currentIndex = words.findIndex(w => currentTime >= w.startTime && currentTime <= w.endTime);
  
  // Group words into "lines" roughly
  const windowSize = 5;
  const startIndex = Math.max(0, (currentIndex === -1 ? 0 : currentIndex) - 2);
  const displayWords = words.slice(startIndex, startIndex + windowSize);

  return (
    <div className="flex justify-center gap-2 items-center h-full px-6">
      {displayWords.map((word, i) => {
        const isActive = words.indexOf(word) === currentIndex;
        const isPast = words.indexOf(word) < currentIndex;

        return (
          <div key={`${word.text}-${word.startTime}`} className="relative">
            <span className="text-2xl font-bold text-white/20 whitespace-nowrap">
              {word.text}
            </span>
            {isPast && (
              <span className="absolute inset-0 text-2xl font-bold text-white whitespace-nowrap">
                {word.text}
              </span>
            )}
            {isActive && (
              <motion.span
                className="absolute inset-0 text-2xl font-bold whitespace-nowrap overflow-hidden text-orange-400"
                initial={{ width: 0 }}
                animate={{ width: '100%' }}
                transition={{ duration: (word.endTime - word.startTime) / 1000, ease: 'linear' }}
              >
                {word.text}
              </motion.span>
            )}
          </div>
        );
      })}
    </div>
  );
};
