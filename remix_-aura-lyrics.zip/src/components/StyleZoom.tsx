import React, { useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LyricWord } from '../types';

interface Props {
  words: LyricWord[];
  currentTime: number;
}

export const StyleZoom: React.FC<Props> = ({ words, currentTime }) => {
  const currentIndex = useMemo(() => {
    return words.findIndex(w => currentTime >= w.startTime && currentTime <= w.endTime);
  }, [words, currentTime]);

  if (currentIndex === -1) {
    // If between words, find the next one
    const nextIndex = words.findIndex(w => w.startTime > currentTime);
    if (nextIndex === -1 && words.length > 0) return null; 
    // Show nothing or the last word
    return null;
  }

  const currentWord = words[currentIndex];
  const prevWord = words[currentIndex - 1];
  const nextWord = words[currentIndex + 1];

  return (
    <div className="flex items-center justify-center gap-4 px-4 overflow-hidden h-full">
      <AnimatePresence mode="popLayout">
        {prevWord && (
          <motion.span
            key={`${prevWord.text}-${currentIndex-1}`}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 0.3, scale: 0.8, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="text-white blur-[1px] whitespace-nowrap"
          >
            {prevWord.text}
          </motion.span>
        )}

        <motion.span
          key={`${currentWord.text}-${currentIndex}`}
          layoutId="active-word"
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1.2, opacity: 1 }}
          className="text-white font-bold text-4xl shadow-xl whitespace-nowrap"
        >
          {currentWord.text}
        </motion.span>

        {nextWord && (
          <motion.span
            key={`${nextWord.text}-${currentIndex+1}`}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 0.3, scale: 0.8, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="text-white blur-[1px] whitespace-nowrap"
          >
            {nextWord.text}
          </motion.span>
        )}
      </AnimatePresence>
    </div>
  );
};
