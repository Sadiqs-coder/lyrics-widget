/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { WidgetPreview } from './components/WidgetPreview';
import { Dashboard } from './components/Dashboard';
import { WidgetConfig, LyricWord } from './types';
import { motion } from 'motion/react';
import { RefreshCw } from 'lucide-react';

const DEFAULT_LYRICS: LyricWord[] = [
  { text: "In", startTime: 1000, endTime: 1500 },
  { text: "the", startTime: 1500, endTime: 1800 },
  { text: "neon", startTime: 1800, endTime: 2500 },
  { text: "light", startTime: 2500, endTime: 3200 },
  { text: "we", startTime: 3200, endTime: 3500 },
  { text: "find", startTime: 3500, endTime: 3800 },
  { text: "our", startTime: 3800, endTime: 4100 },
  { text: "way", startTime: 4100, endTime: 5000 },
  { text: "Through", startTime: 5000, endTime: 5500 },
  { text: "the", startTime: 5500, endTime: 5800 },
  { text: "digital", startTime: 5800, endTime: 6500 },
  { text: "haze", startTime: 6500, endTime: 7200 },
];

export default function App() {
  const [song, setSong] = useState("Vaporwave Dreams");
  const [artist, setArtist] = useState("AI Horizon");
  const [lyrics, setLyrics] = useState<LyricWord[]>(DEFAULT_LYRICS);
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [config, setConfig] = useState<WidgetConfig>({
    style: 'zoom',
    fontSize: 24,
    bgOpacity: 80,
    textAlign: 'center',
    animSpeed: 1,
    fontFamily: 'Inter, sans-serif',
    splitView: false
  });

  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (isPlaying) {
      const start = Date.now() - currentTime;
      timerRef.current = window.setInterval(() => {
        const nextTime = Date.now() - start;
        const maxTime = lyrics[lyrics.length - 1]?.endTime || 0;
        
        if (nextTime > maxTime + 2000) {
          setCurrentTime(0);
        } else {
          setCurrentTime(nextTime);
        }
      }, 16);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, lyrics]);

  const fetchLyrics = async () => {
    setIsLoading(true);
    setIsPlaying(false);
    setCurrentTime(0);
    try {
      const res = await fetch('/api/lyrics/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ song, artist }),
      });
      const data = await res.json();
      if (data.lyrics && data.lyrics.length > 0) {
        setLyrics(data.lyrics);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] flex flex-col items-center justify-center p-6 lg:p-12 gap-12 overflow-x-hidden">
      {/* Background Decorative Elements */}
      <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-orange-500/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-rose-500/10 blur-[120px] rounded-full" />
      </div>

      {/* Widget Preview Section */}
      <div className="relative z-10 w-full flex flex-col items-center gap-4">
        <label className="text-[10px] uppercase tracking-[0.3em] font-bold text-white/30">Live Widget Preview</label>
        <WidgetPreview 
          config={config} 
          words={lyrics} 
          currentTime={currentTime} 
          songInfo={{ title: song, artist: artist, albumArt: "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?auto=format&fit=crop&q=80&w=400&h=200" }}
        />
        {isLoading && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm rounded-3xl z-20"
          >
            <RefreshCw className="animate-spin text-orange-500 mb-2" size={32} />
            <span className="text-xs font-bold uppercase tracking-widest text-white">AI Syncing Lyrics...</span>
          </motion.div>
        )}
      </div>

      {/* Dashboard Section */}
      <div className="relative z-10 w-full flex justify-center">
        <Dashboard 
          config={config} 
          setConfig={setConfig} 
          isPlaying={isPlaying} 
          setIsPlaying={setIsPlaying}
          onRefresh={fetchLyrics}
          song={song}
          setSong={setSong}
          artist={artist}
          setArtist={setArtist}
        />
      </div>

      {/* Footer Info */}
      <div className="relative z-10 text-center max-w-2xl px-4">
        <p className="text-white/40 text-sm leading-relaxed">
          The <span className="text-white">Aura Lyrics Widget</span> uses generative AI to predict word-by-word timestamps when standard LRC data is missing. 
          The high-frequency rendering engine bypasses standard Android refresh limits for fluid, sub-millisecond animations.
        </p>
      </div>

      {/* Import some Google Fonts in index.html if needed, but Tailwind handles most system fonts */}
    </div>
  );
}


