export interface LyricWord {
  text: string;
  startTime: number; // ms
  endTime: number; // ms
}

export type WidgetStyle = 'zoom' | 'typewriter' | 'gradient';

export interface WidgetConfig {
  style: WidgetStyle;
  fontSize: number;
  bgOpacity: number;
  textAlign: 'left' | 'center' | 'right';
  animSpeed: number;
  fontFamily: string;
  splitView: boolean;
}
